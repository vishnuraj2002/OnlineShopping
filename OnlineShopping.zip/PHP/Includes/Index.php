if (isset($_SESSION['email'])) 
{ header('location: products.php'); 
}