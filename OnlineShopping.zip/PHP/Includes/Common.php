<?php
if (!isset($_SESSION['email'])) 
{ 
session_start();
//header('location: products.php'); 
}
?>